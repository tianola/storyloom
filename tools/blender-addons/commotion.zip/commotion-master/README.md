Commotion—Blender add-on for motion graphics.

:arrow_forward: **[Watch Demo v1.0](http://youtu.be/gLj4PvHbm4s)**

Features:

* Offset animation for multiple objects using different sorting methods.
* Works both with F-Curves and NLA strips.
* Copy and link animation between objects.
* Proximity Effector lets you change object properties by distance to other objects.
* Utility tools for absolute shape keys.


How to install
==========================

### Available as an [extension](https://extensions.blender.org/add-ons/commotion/)

<details>
  <summary>For Blender 4.1 or older</summary>

  1. Download [Commotion 2.4.2][download_v2_4_2]
  2. Make sure you have Blender 2.93 or newer.
  3. Open `Preferences` → `Add-ons` category.
  4. Use `Install` to install add-on from downloaded zip archive.
</details>

> [!NOTE]
> For mac users: Safari browser will automatically unpack downloaded zip archive, to prevent that go `Safari` → `Preferences` → `General` and uncheck `Open "safe" files after downloading` option.

> [!WARNING]
> If error occurs on add-on activation, it means you are trying to install add-on repository instead of release. Make sure you download add-on release using link provided in step one of this guide.


Установка
==========================

### Доступно как [расширение](https://extensions.blender.org/add-ons/commotion/)

<details>
  <summary>Для Blender 4.1 или старше</summary>

  1. Загрузите [Commotion 2.4.2][download_v2_4_2]
  2. Убедитесь, что у вас установлен Blender 2.93 или новее.
  3. Откройте `Preferences` → `Add-ons`
  4. Воспользуйтесь `Install` чтобы установить аддон из загруженного архива.
</details>

> [!NOTE]
> Примечание для пользователей mac: браузер Safari автоматически распаковывает скачиваемые zip архивы, чтобы это предотвратить в настройках `Safari` → `Preferences` → `General` отключите опцию `Open "safe" files after downloading`.

> [!WARNING]
> Если при активации аддона возникает ошибка, значит вы пытаетесь установить репозиторий вместо релиза. Для загрузки релиза используйте ссылку, приведённую в первом шаге данного руководства.


Contributing
==========================

### Did you find a bug?

* Ensure the bug can be reproduced in the latest add-on version.
* If error occurs on add-on installation or activation, check [how to install](#how-to-install) guide.
* [Open new issue][new_issue], be sure to include Blender and add-on versions, and screenshot showing the error message.


[download_v2_4_2]: https://github.com/mrachinskiy/commotion/releases/latest/download/commotion-2_4_2.zip
[new_issue]: https://github.com/mrachinskiy/commotion/issues
